package dvd_splash_screen;
import java.awt.*;
import javax.swing.*;
import java.util.logging.*;
import java.io.*;
import java.awt.image.*;
import java.net.URL;
import javax.imageio.ImageIO;

public class DVD_Splash_Screen extends JPanel {
    int x;
    int y;
    int xBorder = 200;
    int yBorder = 100;
    boolean negY = true;
    boolean posX = true;
    
    private RectangleImage dvd = null;
   
    //Icon X & Y movement
    private void iconMovement() {
        if(posX) x += 2;
        else if(!posX) x -= 2;
        
        if(negY) y++;
        else if(!negY) y--;
        
        if(x == (getWidth() - xBorder)) posX = false;
        else if(x == 0) posX = true;
        
        if(y == (getHeight() - yBorder)) negY = false;
        else if(y == 0) negY = true;
    }
    
    //Display Icon Graphic
    @Override
    public void paint(Graphics g) {
        if(dvd == null) {
            try {
                String imagePath = "dvd.png";
                BufferedImage myPicture = ImageIO.read(new File(imagePath));
                dvd = new RectangleImage(myPicture, 200, 100);
            } catch (IOException ex) {
                Logger.getLogger(DVD_Splash_Screen.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        Graphics2D g2 = (Graphics2D)g;
        super.paint(g2);
        dvd.move(x, y);
        dvd.draw(g2, this);
    }
    
    //Fetch Icon Image
    public Image getImage(String path) {
        Image tempImage = null;
        
        try {
            URL imageURL = DVD_Splash_Screen.class.getResource(path);
            tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);
        } catch (Exception e) {
            System.out.println("An error occured - " + e.getMessage());
        }
        return tempImage;
    }
    
    public static void main(String[] args) {
        //Window
        JFrame frame = new JFrame("DVD");
        frame.setSize(1000, 800);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Splash Screen
        DVD_Splash_Screen splashScreen = new DVD_Splash_Screen();
        frame.add(splashScreen);
        
        while(true) {
            splashScreen.iconMovement();
            splashScreen.repaint();
            splashScreen.setBackground(Color.BLACK);
            
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Logger.getLogger(DVD_Splash_Screen.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}

class RectangleImage {
    
    private Image img = null;
    private Rectangle rect = null;
    
    public RectangleImage(Image img, int x, int y) {
        this.img = img;
        ImageIcon icon = new ImageIcon(img);
        this.rect = new Rectangle(x, y, icon.getIconWidth(), icon.getIconHeight());
    }
    
    public Rectangle getRect() {
        return this.rect;
    }
    
    public Image getImg() {
        return this.img;
    }
    
    public void move(int x, int y) {
        this.rect.setBounds(x, y, rect.width, rect.height);
    }
    
    public void draw(Graphics2D g2, ImageObserver o) {
        g2.drawImage(this.img, this.rect.x, this.rect.y, this.rect.width, this.rect.height, null);
    }
}